function customSearch(form) {
    var query = document.getElementById('searchBox').value.toLowerCase();

    if (query === 'io land') {
        window.location.replace('https://sites.google.com/students.odyssey.k12.de.us/iolandgames/'); // Redirects you
        return false; // STOPS the form from going to Google
    }

    form.action = "https://www.google.com/search";
    return true; // ALLOWS the form to go to Google
}
